import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { DepartmentService } from '../department.service';
import { Department } from '../department.model';
import { OrganizationService } from '../../organizations/organization.service';
import { map, filter } from 'rxjs/operators'
import { Observable } from 'rxjs';
import { NzMessageService } from 'ng-zorro-antd';

@Component({
  selector: 'app-departments-list',
  templateUrl: './departments-list.component.html',
  styleUrls: ['./departments-list.component.css']
})
export class DepartmentsListComponent implements OnInit {

  child;
  orgId: string;
  tableView = 'true';
  AllDepartments: Department[];
  orgDepts: Department[] = [];
  childrenData: any[] = [];
  nodes = [];
  root: Department;
  selectedDeptId: number;
  orgName: string;
  constructor(private route: ActivatedRoute,
    private departmentService: DepartmentService,
    private organizationService: OrganizationService,
    private location: Location,
    private router: Router,
    private nzMessageService: NzMessageService) { }

  ngOnInit() {
    this.getDepartments();
    this.getOrg();
    this.getTreeStracture();
    //console.log(this.orgDepts);
    this.tableView = "true";
  }

  getDepartments(): any {
    this.orgId = this.route.snapshot.paramMap.get('orgId');
    console.log(this.orgId)
    this.departmentService.getDepartments().subscribe(AllDepartments => this.AllDepartments = AllDepartments);
    this.AllDepartments.forEach(department => {
      if (department.orgId === this.orgId) {
        //console.log(department)
        this.orgDepts.push(department);
      }
    });

  }
  getOrg() {
    const org = this.organizationService.getOrganization(this.orgId);
    this.orgName = org.name;
  }
  checkChild(departmentId: number) {
    var children = this.departmentService.getChildren(departmentId);
    console.log(children.length);
    if (children.length > 0) {
      children.forEach(child => {
        console.log(child.name); 
        this.childrenData.push( {
          title: child.name,
          key: child.id,
          expanded: true,
          children: this.checkChild(child.id),
          isLeaf: (this.checkChild(child.id) == null) ? true : false
        })
     
      })
      
    } else {
      console.log("else")
      console.log(this.childrenData);

        this.childrenData = [];
    }
    //console.log(this.childrenData);
    return this.childrenData;
  }
  childDetail(childId: number){

  }


  // getDetails(child: Department) {
  //     var childDepts = this.checkChild(child.id)
      
  //     this.childrenData.push( {
  //       title: child.name,
  //       key: child.id,
  //       expanded: true,
  //       children: childDepts,
  //       isLeaf: (childDepts == null) ? true : false
  //     })
  //  return this.childrenData;
    
  // }
  getTreeStracture() {
    this.root = this.orgDepts.find(department => department.parentId == 0);
    this.nodes.push({
      title: this.root.name,
      key: this.root.id,
      expanded: true,
      children: this.checkChild(this.root.id),
      isLeaf: false

    });
    console.log(this.nodes);

  }
  getId(Id: number) {
    this.selectedDeptId = Id;
    console.log(this.selectedDeptId);
  }
  onDelete(): void {

    this.departmentService.deleteDepartment(this.selectedDeptId);
    this.nzMessageService.info('Department Deleted Successfully. ');
    this.router.navigate(["/departments", this.orgId]);
  }
  onCancel(): void {
    this.nzMessageService.info('Task canceled.');
  }


}

    // this.orgDepts.forEach(department => {
    //   departmentIds.push(department.id);  
    // });


